from pathlib import Path
import json,subprocess,wave,csv,re,difflib
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
R=Path('/workspace/heroes-trailer');p=json.loads((R/'plan.json').read_text());sr=48000;voice=np.zeros((120*sr,2),np.int16)
texts=[
'Isliye nahi ki usko punish kiya jaye. Isliye ki usko tough steel banaya jaye.',
'Bina koshish ke nauka paar nahi hoti. Himmat karne walon ki kabhi haar nahi hoti.',
'Kabhi Army ke columns jaate the. Kabhi trucks, kabhi tanks, kabhi mule trains.',
'He was killed in action in the 1965 war.',
'Saab, aap ro nahi sakte.',
'Aapko badla lena. And that is the time I was quite clear what I had to do in life.',
'Ek beta abhi mara hai, doosra beta jaa raha hai. Humne theka le rakha hai fauj mein?',
'Maine leke unko solve karna shuru kiya. Main ghadi se time karta tha. Yahan pe khatam ho jaata tha.',
'And I cleared the written. First attempt.',
'I was number two in the All India merit list for the Army and Air Force.',
'Maine kaha, Dad, yeh meri zindagi hai, yaar. There is no dry run. I am through. Why should I leave it?',
'You go as a boy, you come out as a man.',
'You are toughened up to face any bloody thing in life.',
'Remember, there is no place for a defeated soldier. You either win or you die.',
'Aur train mein baithenge. Aur seedha jahan utrenge, inki paltanein ladai mein hongi.',
'Blood was pouring into his eyes. He wiped the blood with his hands. Shot up one more tank, then another tank.',
'Mere chhe ladke shaheed hue. Ikkees ghayal hue.',
'If you love soldiering, you will never be able to give it up.',
'You will be a soldier all your life.',
'So the sky is the limit. Go out there and achieve.',
'Nabah Sparsham Deeptam.',
'Touch the sky with glory.'
]
assert len(texts)==len(p['voice']),(len(texts),len(p['voice']))
roman={'इसलिए':'isliye','इसले':'isliye','नहीं':'nahi','नही':'nahi','कि':'ki','उसको':'usko','उटको':'usko','पानिश':'punish','पनिष':'punish','किया':'kiya','जाए':'jaye','टाफ':'tough','ताफ':'tough','स्टील':'steel','बनाये':'banaya','गए':'jaye','बिना':'bina','कोशिश':'koshish','के':'ke','नोंका':'nauka','नौका':'nauka','पार':'paar','होती':'hoti','हिम्मत':'himmat','करनेवालों':'karne','की':'ki','कभी':'kabhi','रहार':'haar','और':'aur','आर्मी':'army','जाते':'jaate','थे':'the','साब':'saab','आप':'aap','रो':'ro','सकते':'sakte','सथे':'sakte','आपको':'aapko','बदला':'badla','लेना':'lena','एक':'ek','बेटा':'beta','आभी':'abhi','हमारा':'mara','है':'hai','दूसरा':'doosra','जा':'jaa','रहा':'raha','हमने':'humne','ठेका':'theka','ले':'le','रखा':'rakha','फौज':'fauj','में':'mein','मैंने':'maine','लेके':'leke','उनको':'unko','सुल्व':'solve','करना':'karna','शुरू':'shuru','मैं':'main','गड़ी':'ghadi','घड़ी':'ghadi','से':'se','ताईम':'time','करताता':'karta','यहांपे':'yahan','कतम':'khatam','हो':'ho','जाते':'jaate','ट्रेन':'train','बैठेंगे':'baithenge','सीधा':'seedha','जहां':'jahan','उतरेंगे':'utrenge','इनकी':'inki','पल्टने':'paltanein','लडाई':'ladai','होंगी':'hongi','मेरे':'mere','6':'chhe','छे':'chhe','लड़के':'ladke','लगके':'ladke','शहीद':'shaheed','हुए':'hue','21':'ikkees','गाल':'ghayal','गायल':'ghayal'}
def norm(t):
 t=re.sub(r'[^\w\u0900-\u097f]+','',t.lower());return roman.get(t,t)
words=[]
for i,(c,text) in enumerate(zip(p['voice'],texts)):
 wav=R/f'voice-{i:02}.wav'
 if not wav.exists():subprocess.run(['ffmpeg','-v','error','-y','-ss',str(c['source_a']),'-i','/workspace/reel-review/source.mp4','-t',str(c['source_b']-c['source_a']),'-vn','-ar',str(sr),'-ac','2',str(wav)],check=True)
 with wave.open(str(wav)) as w:a=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,2)
 n=round((c['b']-c['a'])*sr);a=np.pad(a,((0,max(0,n-len(a))),(0,0)))[:n];off=round(c['a']*sr);voice[off:off+n]=a
 name=c['scene'];fn=R/f'{name}-ref.json'
 if not fn.exists():fn=R/f'{name}.json'
 if name=='rank':
  ss=json.loads(Path('/workspace/reel-review/refine-rank.json').read_text());raw=[dict(a=w['start'],b=w['end'],text=w['text']) for s in ss for w in s['words']]
 else:raw=[w for s in json.loads(fn.read_text()) for w in s['words']]
 raw=[w for w in raw if w['b']>c['source_a'] and w['a']<c['source_b'] and w['b']>w['a']]
 toks=text.split();matches=difflib.SequenceMatcher(None,[norm(t) for t in toks],[norm(w['text']) for w in raw],autojunk=False).get_matching_blocks();anchors={}
 for m in matches:
  for k in range(m.size):anchors[m.a+k]=c['a']+max(0,raw[m.b+k]['a']-c['source_a'])
 anchors[-1]=c['a'];anchors[len(toks)]=c['b'];prev=c['a']
 for j,t in enumerate(toks):
  if j in anchors:lo=anchors[j]
  else:
   lower=max(k for k in anchors if k<j);upper=min(k for k in anchors if k>j);lo=anchors[lower]+(anchors[upper]-anchors[lower])*(j-lower)/(upper-lower)
  nxt=min(k for k in anchors if k>j);hi=anchors[nxt] if nxt==j+1 else lo+(anchors[nxt]-lo)/(nxt-j)
  lo=max(prev,min(lo,c['b']-.02));hi=max(lo+.02,min(hi,c['b']));words.append(dict(a=lo,b=hi,text=t,scene=c['scene']));prev=lo
with wave.open(str(R/'voice-original.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(voice.tobytes())
(R/'caption-words-review.json').write_text(json.dumps(words,indent=2,ensure_ascii=False))
def srt(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
groups=[];g=[]
for w in words:
 if g and (len(g)>=3 or w['a']-g[-1]['b']>.4 or w['scene']!=g[-1]['scene']):groups.append(g);g=[]
 g.append(w)
 if w['text'].endswith(('.', '?', '!')):groups.append(g);g=[]
if g:groups.append(g)
out=[]
for i,g in enumerate(groups):
 end=min(g[-1]['b']+.07,groups[i+1][0]['a'] if i+1<len(groups) else 116);out.append(f'{i+1}\n{srt(g[0]["a"])} --> {srt(max(g[0]["a"]+.02,end))}\n'+ ' '.join(w['text'] for w in g))
(R/'Hinglish-Captions-REVIEW.srt').write_text('\n\n'.join(out)+'\n');(R/'caption-groups.json').write_text(json.dumps(groups,ensure_ascii=False))
# Matte originals, purposefully separate from stock footage. No simulated historical events.
for mode,W,H in [('wide',1920,1080),('vertical',1080,1920)]:
 yy,xx=np.mgrid[:H,:W];v=np.maximum(0,1-((xx-W*.45)/(W*.8))**2-((yy-H*.45)/(H*.85))**2);rng=np.random.default_rng(17);noise=rng.normal(0,1,(H,W));a=np.stack([12+v*12+noise,17+v*13+noise,12+v*9+noise],axis=2).clip(0,255).astype('uint8');im=Image.fromarray(a);d=ImageDraw.Draw(im)
 for x in range(0,W,120):d.line((x,0,x,H),fill=(28,34,25),width=1)
 for y in range(0,H,120):d.line((0,y,W,y),fill=(28,34,25),width=1)
 im.save(R/'assets'/f'background-{mode}.png')
logo=Image.open('/workspace/generated_images/exec-b4043cae-a863-40e5-8ea2-9e1751b85a41.png').convert('RGBA');logo=logo.crop(logo.getbbox());logo.thumbnail((152,150));logo.save(R/'assets'/'logo.png')
print('PREPARED',len(words),'words',len(groups),'SRT entries',flush=True)
