from pathlib import Path
import numpy as np,wave,csv,json
R=Path('/workspace/heroes-trailer');sr=48000;dur=120;N=sr*dur;rng=np.random.default_rng(847);music=np.zeros((N,2),np.float32);fx=music.copy();cues=[]
def cue(t,name,length,kind='SFX'):cues.append(dict(time=f'{t:.3f}',duration=f'{length:.3f}',type=kind,description=name,source='Original procedural synthesis; CC0'))
def add(dst,t,x,gain=1,pan=0):
 i=round(t*sr);n=min(len(x),len(dst)-i)
 if n<=0:return
 if x.ndim==1:x=np.stack((x*np.sqrt((1-pan)/2),x*np.sqrt((1+pan)/2)),axis=1)
 dst[i:i+n]+=x[:n]*gain

def tone(f,d,a=.03):
 t=np.arange(round(d*sr))/sr;e=np.minimum(t/.3,1)*np.minimum((d-t)/.6,1);return (np.sin(2*np.pi*f*t)+.22*np.sin(2*np.pi*f*2.002*t))*e*a

def hit(t,label,level=.16,d=1.3):
 x=np.arange(round(d*sr))/sr;s=(np.sin(2*np.pi*(43*x+11*(1-np.exp(-x*8))))*.6+rng.normal(size=len(x))*.06)*np.exp(-x*5);add(fx,t,s,level);cue(t,label,d)
def ping(t,label='Sonar ping',f=730,d=2):
 x=np.arange(round(d*sr))/sr;s=np.sin(2*np.pi*f*x)*np.exp(-x*3)*np.minimum(x/.008,1);add(fx,t,s,.065,-.25);add(fx,t+.16,s,.025,.35);cue(t,label,d+.16)
def air(t,label,d=.45,level=.055):
 x=np.arange(round(d*sr))/sr;n=rng.normal(0,1,len(x));n=np.convolve(n,np.ones(12)/12,'same');env=np.sin(np.pi*x/d)**2;add(fx,t,n*env,level);cue(t,label,d)
def click(t,label,level=.08):
 x=np.arange(round(.12*sr))/sr;v=rng.normal(0,.2,len(x))*np.exp(-x*65)+np.sin(2*np.pi*1900*x)*np.exp(-x*50)*.08;add(fx,t,v,level);cue(t,label,.12)
def ring(t,label='Anvil / steel resonance'):
 d=1.5;x=np.arange(round(sr*d))/sr;v=sum(np.sin(2*np.pi*f*x)*np.exp(-x*(2+i*1.6)) for i,f in enumerate([442,901,1314,2280]))*.08;add(fx,t,v,.55);click(t,'Metal strike',.4);cue(t,label,d)
# Entire musical work is generated from oscillators, filtered noise and newly composed harmony.
add(music,0,tone(36.71,116,.042));add(music,0,tone(55.0,88,.018),pan=.25)
cue(0,'Low drone / D minor',88,'Music');cue(3,'Heartbeat pulse begins',19,'Music');cue(42,'Snare / percussion build',24,'Music');cue(66,'Full disciplined drums',22,'Music');cue(88,'Single-note drop',14,'Music');cue(102,'D-major uplift',14,'Music');cue(116,'Hard musical stop; final hit',4,'Music')
for beat in np.arange(3,22,.6):
 x=np.arange(int(.2*sr))/sr;v=np.sin(2*np.pi*58*x)*np.exp(-x*26);add(music,beat,v,.08);add(music,beat+.17,v,.045)
chords=[[146.832,174.614,220],[116.541,146.832,174.614],[130.813,174.614,220],[146.832,195.998,246.942]]
for t in np.arange(3,88,4.8):
 for j,f in enumerate(chords[int((t-3)/4.8)%4]):add(music,t,tone(f,5.2,.020),pan=(j-1)*.5)
# Regular 100 BPM pulse, with a clear growth from intimate to percussive.
for beat in np.arange(42,88,.6):
 n=round((beat-42)/.6);x=np.arange(int(.32*sr))/sr
 if beat>=66 or n%2==0:add(music,beat,np.sin(2*np.pi*(42*x+2.5*(1-np.exp(-18*x))))*np.exp(-x*18),.13 if beat>=66 else .065)
 if n%2==1:
  v=rng.normal(size=len(x));v=v-np.convolve(v,np.ones(16)/16,'same');add(music,beat,v*np.exp(-x*26),.025 if beat>=66 else .012)
 if beat>=66:add(music,beat+.3,rng.normal(size=int(.08*sr))*np.exp(-np.arange(int(.08*sr))/sr*55),.006,pan=.5)
for f in [73.416,146.832]:add(music,88,tone(f,14,.037))
for t in np.arange(102,116,2.4):
 for j,f in enumerate([[146.832,184.997,220],[195.998,246.942,293.665],[123.471,146.832,184.997],[110,138.591,164.814]][int((t-102)/2.4)%4]):add(music,t,tone(f,2.8,.026),pan=(j-1)*.45)
 for k in range(4):
  x=np.arange(int(.22*sr))/sr;add(music,t+k*.6,np.sin(2*np.pi*52*x)*np.exp(-x*20),.07)
# Original textures and story accents.
air(0,'Radio-static swell',2.7,.075);ping(2);ring(8.4);air(8,'Opening riser',1.8,.07);hit(10,'Title impact / 2.0 stamp');ping(10.2,'Title sonar tail',540,1.6)
# Convoy, wind, bell: non-recorded, illustrative synthetic atmosphere.
add(fx,16,tone(48,4,.024));air(16.4,'Memory wind',2.4,.04);ping(18,'Soft distant bell',1380,.8)
click(25.8,'Heartbeat cut / emotional pause',.05)
air(27,'Low string-like swell',2,.065);hit(30.8,'Quiet vow emphasis',.10,1)
for t in np.arange(36,41.8,.6):click(t,'Clock tick',.10)
click(40.8,'Trunk latch',.45)
for t in np.arange(42,48,.6):click(t,'Stopwatch tick',.13)
air(44.3,'Pen scratch',.7,.07);hit(49.2,'First-attempt stamp',.14,.6);hit(54,'Rank lock',.12,.7);click(54,'Camera shutter',.2)
air(58.8,'Departure whip',.4,.10);ping(60.0,'Railway bell',1220,1.1);air(63,'Train movement',2,.06)
for t in [66,67.2,68.4,69.6,70.8]:hit(t,'Boot-stomp accent',.10,.25)
air(72.9,'Parade transition',.3,.07);hit(76.8,'Charge emphasis',.11,.7);air(81,'Distant train rumble',2,.05)
hit(88,'Sacrifice single-note drop',.10,1.8);air(93.2,'Restrained tank-engine texture',1.5,.04);air(96,'Ridgeline wind',5.5,.045)
air(102,'Uplift transition',1.5,.07);air(110.5,'Jet flyby',2.5,.16)
hit(116,'Final low hit',.26,3.2);ping(117,'Closing sonar',610,2.3)
# Stop all background music exactly at 1:56; leave only the branded hit and its tail.
music[int(116*sr):]=0
for a,b in [(26.5,27.0),(95,96)]:
 lo=int(a*sr);hi=int(b*sr);music[lo:hi]*=.08;fx[lo:hi]*=.08
fade=np.minimum(np.arange(N)/sr/.03,1)*np.minimum((dur-np.arange(N)/sr)/.4,1)
for name,arr in [('music-original.wav',music),('sfx-original.wav',fx)]:
 arr*=fade[:,None]
 with wave.open(str(R/name),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(arr,-.98,.98)*32767).astype('<i2').tobytes())
with (R/'Sound-Cue-Sheet.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['time','duration','type','description','source']);w.writeheader();w.writerows(sorted(cues,key=lambda c:float(c['time'])))
(R/'Music-and-SFX-License.txt').write_text('HEAR FROM THE HEROES 2.0 trailer — original score and sound effects\nOriginal sample-free procedural composition and sound design, 100 BPM.\nAll oscillator melodies, harmony, rhythms, noise textures and effects created for this project. No third-party recordings, samples, music or voices used.\nDedicated under CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/\nGuest and host speech belongs to the supplied source and is excluded from this dedication.\n')
print('SCORE READY',len(cues),'cues',flush=True)
