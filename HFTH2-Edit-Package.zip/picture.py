from pathlib import Path
import json,subprocess,concurrent.futures,csv
R=Path('/workspace/heroes-trailer');p=json.loads((R/'plan.json').read_text());N=3600
for b in p['broll']:
 extra={(18,'boy-clean'):.6,(30.6,'boots'):.6,(39,'chair'):.6,(44.4,'study'):.6,(54,'rank'):.6,(67.2,'rope'):1.2,(76.2,'parade'):1.2,(82.2,'steam'):1.2,(90,'tank'):.6,(97.8,'mountain'):.6,(111,'jet'):.6}.get((b['a'],b['name']),0);b['b']+=extra
stock_by_scene={'steel':'forge','host':'title','boyhood':'boy-clean','loss':'chair','vow':'boots','family':'chair','method':'method','rank':'rank','defiance':'steam','forge':'rope','charge':'parade','war':'steam','sacrifice':'tank','kargil':'mountain','soldier':'flag','sky':'jet'}
states=[]
for f in range(N):
 t=(f+.5)/30;s=next((s for s in p['scenes'] if s['a']<=t<s['b']),None);active=next((v for v in p['voice'] if v['a']<=t<v['b']),None);roll=next((v for v in p['broll'] if v['a']<=t<v['b']),None)
 if t<3:state=('graphic','opening',0)
 elif t>=116:state=('graphic','end',0)
 elif roll:state=('graphic' if roll['name'] in ['title','method','rank'] else 'stock',roll['name'],round(roll['a']*30))
 elif active:state=('podcast',p['voice'].index(active),int(t/2.4)%2)
 else:
  near=min(p['voice'],key=lambda c:min(abs(t-c['a']),abs(t-c['b'])))
  if min(abs(t-near['a']),abs(t-near['b']))<.2:state=('podcast',p['voice'].index(near),int(t/2.4)%2)
  else:
   name=stock_by_scene[s['name']];state=('graphic' if name in ['title','method','rank'] else 'stock',name,round(s['a']*30))
 if states and states[-1]['state']==state:states[-1]['end']=f+1
 else:states.append(dict(start=f,end=f+1,state=state,scene=s['name'] if s else ('opening' if t<3 else 'end')))
for i,q in enumerate(states):
 kind,name,code=q['state'];q['kind']=kind;q['asset']=name;q['duration']=(q['end']-q['start'])/30;q['event']=i+1
 if kind=='podcast':
  v=p['voice'][name];q['file']='/workspace/reel-review/source.mp4';q['source_start']=v['source_a']+q['start']/30-v['a'];q['camera']='wide' if code else 'guest-close';q['camera']='host' if v['scene']=='host' else q['camera']
 elif kind=='stock':q['file']=str(R/'assets'/f'{name}.mp4');q['source_start']=0.3+((q['start']-code)/30*.75)%1.5;q['camera']='illustrative-stock'
 else:q['file']='original-graphics';q['source_start']=0;q['camera']='motion-graphics'
(R/'picture-plan.json').write_text(json.dumps(states,indent=2))
from collections import Counter
c=Counter()
for q in states:
 if q['start']>=90 and q['end']<=3480:c[q['kind']]+=q['end']-q['start']
(R/'picture-ratio.json').write_text(json.dumps(dict(c),indent=2));print('SHOTS',len(states),'BODY RATIO',dict(c),flush=True)
def tc(f):return f'{f//108000:02}:{f//1800%60:02}:{f//30%60:02}:{f%30:02}'
with (R/'Picture-EDL.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['Event','Scene','Media','Type','Source In','Source Out','Record In','Record Out','Camera','Speed'])
 for q in states:w.writerow([q['event'],q['scene'],q['file'],q['kind'],tc(round(q['source_start']*30)),tc(round((q['source_start']+q['duration']*(.75 if q['kind']=='stock' else 1))*30)),tc(q['start']),tc(q['end']),q['camera'],'.75' if q['kind']=='stock' else '1'])
for mode in ['wide','vertical']:(R/f'parts-{mode}').mkdir(exist_ok=True)
meta={}
for q in states:
 if q['kind']=='stock' and q['file'] not in meta:
  d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height','-select_streams','v:0','-of','json',q['file']]))['streams'][0];meta[q['file']]=d

def render(job):
 mode,q=job;W,H=(1920,1080) if mode=='wide' else (1080,1920);dest=R/f'parts-{mode}'/f'{q["event"]:03}.mp4'
 if dest.exists():return
 n=q['end']-q['start'];cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','1','-filter_complex_threads','1','-filter_threads','1'];kind=q['kind']
 if kind=='graphic':
  cmd+=['-loop','1','-framerate','30','-i',str(R/'assets'/f'background-{mode}.png')];vf=f'fps=30,setsar=1'
 else:
  cmd+=['-ss',str(q['source_start']),'-i',q['file']]
  if kind=='podcast':
   cam=q['camera'];layout=('single' if int(q['asset']) in [1,2,7,9,11,12,13,15,16] else ('two-shot' if int(q['asset']) in [4,5,6,10] else 'split'));base='delogo=x=1730:y=5:w=180:h=135:show=0,'
   if mode=='wide':
    if cam=='guest-close' and layout=='two-shot':base+='crop=1080:608:840:210,'
    vf=base+f"zoompan=z='1+on*.0003':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s={W}x{H}:fps=30"
   else:
    if cam=='host':base+='crop=608:1080:650:0,'
    elif cam=='guest-close':base+=f'crop=608:1080:{650 if layout=="single" else (1240 if layout=="two-shot" else 1136)}:0,'
    else:base+=f'crop=810:1080:{550 if layout=="single" else (1080 if layout=="two-shot" else 1035)}:0,'
    frame_h=H if cam in ['host','guest-close'] else 1440
    vf=base+f"zoompan=z='1+on*.00035':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s={W}x{frame_h}:fps=30"
    if frame_h!=H:vf+=',pad=1080:1920:0:240:color=0x0c110c'
   vf+=',setsar=1,eq=saturation=.71:contrast=1.045:brightness=-.005,colorbalance=rs=.015:gs=.013:bs=-.012,vignette=PI/7,noise=alls=2:allf=t'
  else:
   m=meta[q['file']]
   if mode=='wide' and m['height']>m['width']:
    vf=f"[0:v]setpts=(PTS-STARTPTS)/.75,fps=30,split[bg][fg];[bg]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=35:2,eq=brightness=-.14[back];[fg]scale=-2:{H}[front];[back][front]overlay=(W-w)/2:(H-h)/2,setsar=1,eq=saturation=.58:contrast=1.08,colorbalance=rs=.02:gs=.012:bs=-.012,vignette=PI/6,noise=alls=2:allf=t[v]"
   else:vf=f'setpts=(PTS-STARTPTS)/.75,fps=30,scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,eq=saturation=.58:contrast=1.08,colorbalance=rs=.02:gs=.012:bs=-.012,vignette=PI/6,noise=alls=2:allf=t'
 if '[v]' in vf:cmd+=['-filter_complex',vf,'-map','[v]']
 else:cmd+=['-vf',vf]
 cmd+=['-frames:v',str(n),'-an','-c:v','libx264','-threads','2','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',str(dest)]
 subprocess.run(cmd,check=True);print(mode,q['event'],'/',len(states),q['scene'],kind,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(render,[(m,q) for q in states for m in ['wide','vertical']]))
for mode in ['wide','vertical']:
 f=R/f'concat-{mode}.txt';f.write_text(''.join("file '"+str(R/f'parts-{mode}'/f'{q["event"]:03}.mp4')+"'\n" for q in states));subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(f),'-c','copy',str(R/f'picture-{mode}.mp4')],check=True)
print('BOTH PICTURES READY',flush=True)
