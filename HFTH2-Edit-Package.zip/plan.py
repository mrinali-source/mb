from pathlib import Path
import json,csv
R=Path('/workspace/heroes-trailer');F=30
rows=[
 ('steel',3,10,[(3.2,918.9,925.3)],'TOUGH STEEL'),
 ('host',10,15,[(10.2,2,6.5)],'HEAR FROM THE HEROES'),
 ('boyhood',15,22,[(15.1,125.26,131.96)],'THE FIRST SPARK'),
 ('loss',22,27,[(22.1,276,280.62)],'1965'),
 ('vow',27,36,[(27.1,360.9,363.42),(29.7,364.78,371.02)],'THE VOW'),
 ('family',36,42,[(36.1,382.1,387.9)],'ONE SON LOST. THE OTHER LEAVING.'),
 ('method',42,52,[(42.1,470.82,476.98),(48.6,524.65,527.72)],'FIRST ATTEMPT. CLEARED.'),
 ('rank',52,59,[(52.3,573.22,579.1)],'ALL INDIA RANK 2'),
 ('defiance',59,66,[(59.2,608.79,614.05)],'NO DRY RUN.'),
 ('forge',66,73,[(66.2,886.86,889.08),(68.6,889.62,893.5333333333)],'BOY / MAN'),
 ('charge',73,80,[(73.2,1014.58,1020.04)],'THE CHARGE'),
 ('war',80,88,[(80.2,1300.2,1307.34)],'14 NOV 1971'),
 ('sacrifice',88,96,[(88.1,1517,1524.48)],'LT ARUN KHETARPAL'),
 ('kargil',96,102,[(96.2,2383,2387.22)],'6 MARTYRED. 21 WOUNDED.'),
 ('soldier',102,108,[(102.2,2329.54,2332.48),(105.2,2333.22,2335.62)],'SOLDIER FOR LIFE'),
 ('sky',108,116,[(108,3531.58,3535.44),(111.9,3536.82,3538.82),(113.9,3539,3541)],'THE SKY IS THE LIMIT')]
scenes=[];voice=[]
for name,a,b,clips,title in rows:
 scene=dict(name=name,a=a,b=b,title=title,clips=[])
 for off,src,stop in clips:
  off=round(off*F)/F;src=round(src*F)/F;stop=round(stop*F)/F
  c=dict(scene=name,a=off,b=off+stop-src,source_a=src,source_b=stop)
  assert c['b']<=b+.001,(name,c)
  for x,y in [(304,354),(1167,1226),(1613,2140),(2430,2642),(2688,2990),(2992,3404)]:assert stop<=x or src>=y
  scene['clips'].append(c);voice.append(c)
 scenes.append(scene)
# Sparse, purposeful inserts; remaining breathing spaces use original chapter graphics.
roll=[(3,5.4,'forge'),(8.4,9.6,'boots'),(12.6,15,'title'),(18,19.8,'boy-clean'),(24,25.8,'chair'),(30.6,31.8,'boots'),(39,40.8,'chair'),(44.4,46.2,'study'),(49.2,50.4,'method'),(54,55.2,'rank'),(63,65.4,'steam'),(67.2,68.4,'rope'),(70.8,72,'boots'),(76.2,77.4,'parade'),(82.2,83.4,'steam'),(86.4,87.6,'mountain'),(90,91.8,'tank'),(94.2,95.4,'gear'),(97.8,99,'mountain'),(106.2,107.4,'flag'),(111,112.2,'jet')]
plan=dict(duration=120,fps=30,bpm=100,scenes=scenes,voice=voice,broll=[dict(a=a,b=b,name=n) for a,b,n in roll],notes=['User approved shifting source boundaries to complete quotes. All excluded ranges remain absent.','Fixed major chapter times follow the supplied timeline; internal picture cuts land on the 100 BPM grid.','AIR 2 remains an attributed recollection, not independently verified.','User approved SRT captions; final exports burn in animated word captions.','No handle or date supplied; end card omits placeholders and handle per earlier instruction.'])
(R/'plan.json').write_text(json.dumps(plan,indent=2));print('Voice seconds',sum(c['b']-c['a'] for c in voice),'stockplanned',sum(b-a for a,b,n in roll))
def tc(t):
 f=round(t*30);return f'{f//108000:02}:{f//1800%60:02}:{f//30%60:02}:{f%30:02}'
with (R/'Dialogue-EDL.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['Event','Scene','Source','Source In 30fps','Source Out Exclusive','Record In','Record Out Exclusive'])
 for i,c in enumerate(voice,1):w.writerow([i,c['scene'],'source.mp4',tc(c['source_a']),tc(c['source_b']),tc(c['a']),tc(c['b'])])
edl=['TITLE: HEAR FROM THE HEROES 2.0 - DIALOGUE','FCM: NON-DROP FRAME','']
for i,c in enumerate(voice,1):edl.extend([f'{i:03}  PODCAST  A     C        {tc(c["source_a"])} {tc(c["source_b"])} {tc(c["a"])} {tc(c["b"])}','* FROM CLIP NAME: source.mp4','* SCENE: '+c['scene'],''])
(R/'Dialogue.edl').write_text('\n'.join(edl))
