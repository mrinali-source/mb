HEAR FROM THE HEROES 2.0 / EPISODE 2 / EDIT PACKAGE

Videos: two-minute landscape 1920x1080 and vertical 1080x1920, 30fps.
The user has approved the supplied Hinglish SRT; animated captions are burned into both final exports.
Final-*.ass combines motion graphics with approved animated captions.

Included:
Dialogue.edl + Dialogue-EDL.csv: original speaker edit, exact 30fps timecodes.
Picture-EDL.csv: every picture cut, source, speed and frame timing.
Graphics-*.ass: title, ribbon, quote and lower-third motion graphics.
Captions-*-READY-TO-BURN.ass: timed word animations for caption approval/revision.
Sound-Cue-Sheet.csv: every designed sound cue and musical section.
B-Roll-Licences.csv + Credits-and-Edit-Notes.md: all footage and rights.
plan.json + picture-plan.json: frame-accurate sequence decisions.
Python scripts: reproducible assembly, generated score and graphic preparation.

All media time intervals use exclusive out points.
Source podcast and full-resolution stock downloads are not duplicated in this ZIP.
Stock source URLs, licences, and local edit decisions are included.

The Python scripts reference working-directory paths. Restore the original podcast and licensed stock, then adjust the root paths before rebuilding.
The SRT file retains its REVIEW filename for continuity; the user has approved its wording.
