from pathlib import Path
import json,math
R=Path('/workspace/heroes-trailer');P=json.loads((R/'plan.json').read_text());groups=json.loads((R/'caption-groups.json').read_text())
B='&H4BA2C9&';S='&HC0DCE6&';W='&HF6F7F8&';M='&H2F2A8C&';OL='&H22332B&'
def ts(t):
 n=round(t*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'
for mode,Wd,H in [('wide',1920,1080),('vertical',1080,1920)]:
 E=[];C=[];cx=Wd//2;portrait=mode=='vertical';safeX=96 if not portrait else 72;low=922 if not portrait else 1620
 def ev(a,b,text,layer=5,caption=False):
  if b>a:(C if caption else E).append(f'Dialogue: {layer},{ts(a)},{ts(b)},Text,,0,0,0,,{text}')
 def txt(a,b,text,x,y,size=60,color=W,font='Big Shoulders Display ExtraBold',extra='',align=5,layer=5,caption=False):ev(a,b,f'{{\\an{align}\\pos({x},{y})\\fn{font}\\fs{size}\\c{color}\\bord0\\shad0{extra}}}'+text,layer,caption)
 def rect(a,b,x,y,w,h,color=B,alpha='00',extra='',layer=2):ev(a,b,f'{{\\an7\\pos({x},{y})\\c{color}\\1a&H{alpha}&\\bord0\\shad0{extra}\\p1}}m 0 0 l {w} 0 {w} {h} 0 {h}',layer)
 def bar(a,b,y=low-120,h=180):rect(a,b,safeX-10,y,Wd-2*safeX+20,h,'&H000000&','66',extra='\\fad(100,170)')
 def ring(a,b,x,y,r,color=B,scale=False):
  # Four Bezier arcs; unfilled ring uses vector outline, not a filled orb.
  k=.55228475*r;path=f'm {r} 0 b {r} {k} {k} {r} 0 {r} b {-k} {r} {-r} {k} {-r} 0 b {-r} {-k} {-k} {-r} 0 {-r} b {k} {-r} {r} {-k} {r} 0'
  ext='\\fscx10\\fscy10\\t(0,2200,\\fscx300\\fscy300)' if scale else ''
  ev(a,b,f'{{\\an5\\pos({x},{y})\\c{color}\\1a&HFF&\\3c{color}\\3a&H45&\\bord1.5\\shad0\\fad(200,600){ext}\\p1}}'+path,1)
 def ribbon(a,b,y,scale=1):
  sw=15*scale;hh=120*scale
  for i,c in enumerate([M,S,B,S,M]):
   delay=i*.08;ev(a+delay,b,f'{{\\an7\\move({cx+(i-2.5)*sw},-180,{cx+(i-2.5)*sw},{y},0,380)\\c{c}\\bord0\\shad0\\fad(40,180)\\p1}}m 0 0 l {sw-2} 0 {sw-2} {hh} {sw/2} {hh-10} 0 {hh}',3)
 # Opening black and a faint expanding sonar ring at 0:02.
 rect(0,3,0,0,Wd,H,'&H000000&');ring(1.8,3.05,0,int(H*.52),120,scale=True)
 # Recurring discreet podcast branding. Source logo is removed from interview shots.
 txt(3,116,'THE DEFENCE ASPIRANT ACADEMY',safeX,85 if not portrait else 145,25 if not portrait else 25,S,extra='\\fsp1.4\\fad(160,160)',align=7)
 # Host title entry, then a full original title plate.
 rect(10.2,12.6,0,780 if not portrait else 1300,Wd,300 if not portrait else 620,'&H000000&','12')
 txt(10.2,12.6,'HEAR FROM THE HEROES',safeX,825 if not portrait else 1370,72 if not portrait else 65,W,extra='\\clip(0,0,0,1920)\\t(0,500,\\clip(0,0,1920,1920))\\fad(90,120)',align=7)
 txt(10.55,12.6,'2.0   /   EPISODE 2',safeX,915 if not portrait else 1455,38,B,extra='\\fad(90,120)',align=7)
 ribbon(12.6,15,145 if not portrait else 420,1 if not portrait else 1.25)
 txt(12.68,15,'HEAR FROM',cx,415 if not portrait else 790,128 if not portrait else 118,W,extra='\\fad(80,100)')
 txt(12.78,15,'THE HEROES',cx,570 if not portrait else 935,166 if not portrait else 140,W,extra='\\fad(80,100)')
 rect(12.95,15,cx-90,680 if not portrait else 1060,180,92,M,extra='\\fscx120\\fscy120\\t(0,150,\\fscx100\\fscy100)\\fad(20,120)')
 txt(12.95,15,'2.0',cx,723 if not portrait else 1105,72,W,extra='\\fad(20,120)')
 txt(13.05,15,'THE DEFENCE ASPIRANT ACADEMY',cx,832 if not portrait else 1230,36 if not portrait else 32,S,extra='\\fsp1\\fad(120,100)')
 # Guest identification, held as a proper lower third.
 bar(15.2,18.4,low-100,145)
 rect(15.2,18.4,safeX,low-96,Wd*.40,3,B,extra='\\fscx0\\t(0,267,\\fscx100)\\fad(0,160)')
 txt(15.47,18.4,'MAJ GEN G. D. BAKSHI',safeX,low-62,47 if not portrait else 49,W,extra='\\fad(100,160)',align=7)
 txt(15.6,18.4,'Udhampur, 1955',safeX,low+2,34,S,'Newsreader',extra='\\i1\\fad(100,160)',align=7)
 # Sparse, specifically requested graphical emphasis; running captions remain separate.
 def popup(a,b,text,y=low,size=90,color=B,font='Big Shoulders Display ExtraBold'):
  txt(a,b,text,cx,y,size,color,font,extra='\\fscx84\\fscy84\\t(0,160,.5,\\fscx104\\fscy104)\\t(160,260,\\fscx100\\fscy100)\\bord1\\3c&H000000&\\shad2\\fad(70,180)')
 popup(8.15,9.8,'TOUGH STEEL',low,108 if not portrait else 105)
 bar(22.3,26.5,low-110,155);txt(22.3,26.5,'1965',safeX,low-80,90,B,extra='\\fad(100,180)',align=7)
 txt(22.5,26.5,'HE WAS 15. HIS BROTHER WAS 23.',safeX,low+25,33 if not portrait else 32,S,extra='\\fad(100,180)',align=7)
 popup(27.3,29.6,'Aap ro nahi sakte.',low-40,66 if not portrait else 71,W,'Newsreader')
 bar(36.4,41.7,low-110,170)
 txt(36.4,41.7,'One son lost.',cx,low-65,66 if not portrait else 68,W,'Newsreader',extra='\\i1\\fad(160,180)')
 txt(36.65,41.7,'The other leaving.',cx,low+16,66 if not portrait else 68,S,'Newsreader',extra='\\i1\\fad(160,180)')
 # Stopwatch and paper are original motion graphics.
 ring(49.2,51.8,cx,410 if not portrait else 760,100)
 y=410 if not portrait else 760
 ev(49.2,51.8,f'{{\\an7\\pos({cx},{y})\\org({cx},{y})\\frz0\\t(0,2400,\\frz360)\\c{M}\\bord0\\shad0\\p1}}m -2 0 l 2 0 2 -85 -2 -85')
 txt(49.25,51.8,'FIRST ATTEMPT.',cx,650 if not portrait else 1060,92 if not portrait else 98,W,extra='\\fad(50,150)')
 txt(49.4,51.8,'CLEARED.',cx,765 if not portrait else 1180,112 if not portrait else 120,B,extra='\\fscx120\\fscy120\\t(0,160,\\fscx100\\fscy100)\\fad(50,150)')
 # Rank is expressly attributed, pending independent documentary verification.
 for j,n in enumerate([50,29,12,7,3,2]):txt(54+j*.1,54+(j+1)*.1,str(n),cx,500 if not portrait else 850,220 if not portrait else 260,B)
 txt(54.6,56.1,'2',cx,500 if not portrait else 850,220 if not portrait else 260,B,extra='\\fad(0,130)')
 txt(54,56.1,'ALL INDIA MERIT',cx,710 if not portrait else 1115,70 if not portrait else 75,W)
 txt(54.1,56.1,'ARMY & AIR FORCE',cx,800 if not portrait else 1200,35,S)
 txt(54.1,56.1,'AS RECALLED BY GEN. BAKSHI',cx,862 if not portrait else 1270,27,S)
 popup(61.45,63.9,'NO DRY RUN.',low-30,110 if not portrait else 105)
 popup(66.3,67.35,'BOY',low-25,106,W)
 popup(67.35,68.7,'MAN',low-25,115,B)
 # Small provenance statement for the Manekshaw recollection.
 bar(73.2,79.6,low-20,95)
 attrib='As recalled by Gen. Bakshi: Field Marshal Manekshaw, NDA passing-out parade'
 if portrait:attrib='As recalled by Gen. Bakshi: Field Marshal Manekshaw\\NNDA passing-out parade'
 txt(73.3,79.6,attrib,cx,low+28,25 if not portrait else 25,S,'Newsreader',extra='\\i1\\fad(120,160)')
 popup(76.9,78.9,'Win. or die.',low-105,82 if not portrait else 88,W,'Newsreader')
 bar(80.3,87.7,low-100,150);txt(80.3,87.7,'14 NOV 1971',safeX,low-73,80 if not portrait else 76,B,extra='\\fad(90,160)',align=7)
 txt(80.5,87.7,'FROM TRAINING TO DUTY',safeX,low+20,34,S,extra='\\fad(90,160)',align=7)
 # Restrained route-line animation, a conceptual travel graphic rather than a battle map.
 rect(81,84,safeX,low-128,Wd-2*safeX,2,B,alpha='60',extra='\\fscx0\\t(0,2400,\\fscx100)\\fad(80,140)')
 bar(88.4,95.7,low-125,195)
 txt(88.4,95.7,'2ND LT ARUN KHETARPAL',safeX,low-100,53 if not portrait else 51,W,extra='\\fad(110,180)',align=7)
 txt(88.6,95.7,'PVC (posthumous)  /  He was 21.',safeX,low-24,39 if not portrait else 35,S,'Newsreader',extra='\\i1\\fad(110,180)',align=7)
 rect(88,88.12,0,0,Wd,H,M,'E9')
 popup(97.8,100.5,'6 MARTYRED.',low-100,90 if not portrait else 99,W)
 popup(98.0,100.5,'21 WOUNDED.',low+12,90 if not portrait else 99,B)
 txt(97.8,100.5,'KARGIL',cx,low-205,35,S,extra='\\fsp4\\fad(100,160)')
 popup(104.8,107.6,'SOLDIER FOR LIFE',low-35,92 if not portrait else 90,B)
 popup(109.0,111.4,'THE SKY IS THE LIMIT',low-35,86 if not portrait else 86,W)
 txt(111.95,113.9,'NABAH SPARSHAM DEEPTAM',cx,low-20,51 if not portrait else 53,B,extra='\\fad(90,160)')
 txt(113.95,115.9,'Touch the sky with glory.',cx,low-20,65 if not portrait else 67,W,'Newsreader',extra='\\i1\\fad(90,150)')
 # End card, no unresolved handle/date placeholders.
 ribbon(116,120,205 if not portrait else 500,1 if not portrait else 1.2)
 txt(116.25,120,'HEAR FROM',cx,460 if not portrait else 840,112 if not portrait else 116,W,extra='\\fad(170,400)')
 txt(116.35,120,'THE HEROES',cx,595 if not portrait else 985,145 if not portrait else 140,W,extra='\\fad(170,400)')
 rect(116.5,120,cx-62,687 if not portrait else 1090,124,70,M,extra='\\fad(120,400)')
 txt(116.5,120,'2.0',cx,720 if not portrait else 1124,56,W,extra='\\fad(120,400)')
 txt(116.65,120,'EPISODE 2: MAJ GEN G. D. BAKSHI',cx,815 if not portrait else 1290,43 if not portrait else 41,S,extra='\\fad(140,400)')
 txt(116.8,120,'THE DEFENCE ASPIRANT ACADEMY',cx,888 if not portrait else 1380,30 if not portrait else 29,S,extra='\\fsp1\\fad(140,400)')
 txt(117.0,120,'Full episode out now',cx,965 if not portrait else 1510,45 if not portrait else 52,B,'Newsreader',extra='\\i1\\fad(160,400)')
 # Ready-to-burn captions, supplied separately until the SRT review is complete.
 keyword={'steel','nahi','army','1965','ro','badla','beta','time','first','two','zindagi','dry','boy','man','soldier','win','die','train','blood','tank','shaheed','ghayal','love','life','sky','limit','deeptam','glory'}
 from PIL import ImageFont
 fnt=ImageFont.truetype(str(R/'fonts'/'BigShouldersDisplay-ExtraBold.ttf'),68 if not portrait else 76)
 for gi,g in enumerate(groups):
  fs=68 if not portrait else 76;gap=20 if not portrait else 25;labels=[w['text'].upper() for w in g];widths=[fnt.getlength(x) for x in labels];tw=sum(widths)+gap*(len(g)-1);scale=min(1,(Wd*.84)/tw);x=cx-tw*scale/2
  end=min(116,g[-1]['b']+.04,groups[gi+1][0]['a'] if gi+1<len(groups) else 116)
  for w,label,ww in zip(g,labels,widths):
   col=B if w['text'].lower().strip('.,?!') in keyword else W
   cap_y=(980 if not portrait else 1490) if 10<=g[0]['a']<15 else ((low-320) if 96<=g[0]['a']<102 else ((low-240) if any(a<=g[0]['a']<b for a,b in [(15,19),(22,27),(36,42),(73,80),(80,88),(88,96),(96,102),(102,108)]) else low-14))
   txt(w['a'],end,label,round(x+ww*scale/2),cap_y,round(fs*scale),col,extra='\\bord1.5\\3c&H000000&\\shad2.4\\blur.2\\fscx85\\fscy85\\t(0,140,.5,\\fscx100\\fscy100)\\fad(55,0)',caption=True);x+=(ww+gap)*scale
 header=f'''[Script Info]\nScriptType: v4.00+\nPlayResX: {Wd}\nPlayResY: {H}\nScaledBorderAndShadow: yes\nWrapStyle: 2\n\n[V4+ Styles]\nFormat: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding\nStyle: Text,Big Shoulders Display ExtraBold,60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,0,0,5,60,60,60,1\n\n[Events]\nFormat: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text\n'''
 (R/f'Graphics-{mode}.ass').write_text(header+'\n'.join(E)+'\n');(R/f'Captions-{mode}-READY-TO-BURN.ass').write_text(header+'\n'.join(C)+'\n')
 remove=['}TOUGH STEEL','}Aap ro nahi sakte.','}NO DRY RUN.','}BOY','}MAN','}Win. or die.','}THE SKY IS THE LIMIT','}NABAH SPARSHAM DEEPTAM','}Touch the sky with glory.']
 finalE=[e for e in E if not any(e.endswith(k) for k in remove)]
 (R/f'Final-{mode}.ass').write_text(header+'\n'.join(finalE+C)+'\n')
 print(mode,len(finalE),'final graphics',len(C),'word animations')
