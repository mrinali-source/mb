from pathlib import Path
import subprocess,concurrent.futures,json
R=Path('/workspace/heroes-trailer')
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'mix-normalized.wav'),'-af','volume=-0.49dB','-c:a','aac','-b:a','256k','-ar','48000',str(R/'Soundtrack.m4a')],check=True)
def render(mode):
 W,H=(1920,1080) if mode=='wide' else (1080,1920);sz=128 if mode=='wide' else 144;y=76 if mode=='wide' else 138;end_y=85 if mode=='wide' else 300
 ass=R/f'Final-{mode}.ass'
 vf=f"[0:v]setpts=N/(30*TB),setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709,scale=iw*1.03:ih*1.03,crop={W}:{H}:x='(in_w-out_w)/2+if(between(t,8.25,8.55),{W}*.012*sin(t*112),0)':y='(in_h-out_h)/2+if(between(t,8.25,8.55),{H}*.012*cos(t*95),0)',ass=filename='{ass}':fontsdir='{R}/fonts'[v];[2:v]split[l1][l2];[l1]scale={sz}:-1[brand];[l2]scale=152:-1[end];[v][brand]overlay=x=W-w-{int(W*.06)}:y={y}:enable='between(t,3,115.99)'[b];[b][end]overlay=x=(W-w)/2:y={end_y}:enable='gte(t,116)',fade=t=out:st=119.6:d=0.4,setsar=1,format=yuv420p[out]"
 out=R/f'HEAR-FROM-THE-HEROES-2-{ "16x9" if mode=="wide" else "9x16" }-FINAL.mp4'
 cmd=['ffmpeg','-hide_banner','-y','-threads','2','-filter_complex_threads','1','-reinit_filter','0','-i',str(R/f'picture-{mode}.mp4'),'-i',str(R/'Soundtrack.m4a'),'-loop','1','-framerate','30','-i',str(R/'assets/logo.png'),'-filter_complex',vf,'-map','[out]','-map','1:a:0','-frames:v','3600','-t','120','-r','30','-c:v','libx264','-preset','veryfast','-crf','18','-maxrate','6M','-bufsize','12M','-threads','2','-c:a','copy','-movflags','+faststart','-metadata','title=HEAR FROM THE HEROES 2.0 — Episode 2 — Final Trailer',str(out)]
 with (R/f'render-{mode}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
 print('READY',out.name,out.stat().st_size,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(render,['wide','vertical']))
